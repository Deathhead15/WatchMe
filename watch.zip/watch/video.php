<?php
session_start();
$user = $_SESSION['username'];
$dbuser = $_COOKIE['user'];
    function getConn()
    {
      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "dirkrhys15";
      $dbname = "movie";
      $conn =  mysqli_connect($dbhost, $dbuser, $dbpass) or die('cannot connect to the server');
      mysqli_select_db($conn, $dbname) or die('database selection problem');
      return $conn;
    }
?>
<!DOCTYPE html>
<html>
<head>
<title>Watch Me</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<script type="text/javascript" src="layout/scripts/jquery.min.js"></script>
<script type="text/javascript" src="layout/scripts/jquery.jcarousel.pack.js"></script>
<script type="text/javascript" src="layout/scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="layout/scripts/jquery.jcarousel.setup.js"></script>

</head>
<body id="top">
<div class="wrapper col1">
  <div id="topbar">
    
    <ul>
        <li><?php echo $user; ?></li>
        <li class="last"><a href="../index.php">Logout</a></li>
    </ul>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="header">
    <div class="fl_left">
      <h1>Watch Me Inc.</h1>
      <p></p>
    </div>
    
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col3">
  <div id="topnav">
    <ul>
      <li><a href="index.php">Homepage</a></li>
        <li class="active"><a>VIDEO</a></li>
      
      
    </ul>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div id="movieinfo">
    
        <?php 
            if(isset($_POST['rent'])){
            $dbid = $_POST['id'];
            $str1 = "";
            @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");
            @$query = mysqli_query(getConn(), "SELECT * FROM movie where id = $dbid");
            @$numrows = mysqli_num_rows($query);
            while ($row = mysqli_fetch_assoc($query))
            {
                $dbvidpath = $row['videopath'];
                $str1 .="<div class='wrappervideo' id='".$row['id']."'>";
                $str1 .= "<img class='imgl' src=" . $row['picturepath'] . " alt=".$row['title']." width='150' height='200' >";
                $str1 .= "<p><strong>".$row['title']."</strong></p>";
                $str1 .= "<p>".$row['genre']."</p>";
                $str1 .= "<p>".$row['description']."</p>";
                $str1 .= "<form method='post' action='video.php'>";
                $str1 .= "<input type='hidden' name='id' value='" . $row['id'] . "' >";
                $str1 .= "<button type='submit' name='watch' >Watch</button>";
                $str1 .= "</form>";
                $str1 .= "</div>";
                
            }
                @mysqli_close(getConn());
                echo $str1;
            }
            if(isset($_POST['new2'])){
            $dbid = $_POST['store2'];
            $str1 = "";
            @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");
            @$query = mysqli_query(getConn(), "SELECT * FROM movie where id = $dbid");
            @$numrows = mysqli_num_rows($query);
            while ($row = mysqli_fetch_assoc($query))
            {
                $dbvidpath = $row['videopath'];
                $str1 .="<div class='wrappervideo' id='".$row['ID']."'>";
                $str1 .= "<img class='imgl' src=" . $row['picturepath'] . " alt=".$row['title']." width='150' height='200' >";
                $str1 .= "<p><strong>".$row['title']."</strong></p>";
                $str1 .= "<p>".$row['genre']."</p>";
                $str1 .= "<p>".$row['description']."</p>";
                $str1 .= "<form method='post' action='video.php'>";
                $str1 .= "<input type='hidden' name='id' value='" . $row['id'] . "' >";
                $str1 .= "<button type='submit' name='watch' >Watch</button>";
                $str1 .= "</form>";
                $str1 .= "</div>";
                
            }
                @mysqli_close(getConn());
                echo $str1;
            }
            if(isset($_POST['new1'])){
            $dbid = $_POST['store1'];
            $str1 = "";
            @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");
            @$query = mysqli_query(getConn(), "SELECT * FROM movie where id = $dbid");
            @$numrows = mysqli_num_rows($query);
            while ($row = mysqli_fetch_assoc($query))
            {
                $dbvidpath = $row['videopath'];
                $str1 .="<div class='wrappervideo' id='".$row['id']."'>";
                $str1 .= "<img class='imgl' src=" . $row['picturepath'] . " alt=".$row['title']." width='150' height='200' >";
                $str1 .= "<p><strong>".$row['title']."</strong></p>";
                $str1 .= "<p>".$row['genre']."</p>";
                $str1 .= "<p>".$row['description']."</p>";
                $str1 .= "<form method='post' action='video.php'>";
                $str1 .= "<input type='hidden' name='id' value='" . $row['id'] . "' >";
                $str1 .= "<button type='submit' name='watch' >Watch</button>";
                $str1 .= "</form>";
                $str1 .= "</div>";
                
            }
                @mysqli_close(getConn());
                echo $str1;
            }
            ?>
</div>


<div class="wrapper col6">
  <div id="footer">
      <div id="movie" class='movievideo'>
          <?php
          if(isset($_POST['watch'])) {
            $usermovie = $_COOKIE['user'];
            $dbid = $_POST['id'];
            @$db_user = mysqli_select_db(getConn(), 'login') or die("Dead");
              $q = "SELECT * FROM users WHERE username = $usermovie";
            $queryuser = mysqli_query(getConn(), $q);
            $numrows = mysqli_num_rows($queryuser);
            if ($numrows !== 0) {
                while ($row = mysqli_fetch_assoc($queryuser)) {
                    $dbusername = $row['username'];
                    $dbpremium = $row['premium'];
                    $dbmovie = $row['movie'];
                    $userid = $row['id'];
                }

                if($dbpremium==1){
                    if($dbmovie<=9){
                        $dbmovie++;
                        $db_user = mysqli_select_db(getConn(), 'login') or die("Dead");
                        $queryprem = mysqli_query(getConn(), "UPDATE users SET movie=$dbmovie WHERE username = '$usermovie'");

                        @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");
                        @$query = mysqli_query(getConn(), "SELECT * FROM movie where id = $dbid");
                        @$numrows = mysqli_num_rows($query);
                        while ($row = mysqli_fetch_assoc($query)) {
                            $dbvidpath = $row['videopath'];
                        }
                        echo "<video  style= 'width:853px; height:480px;' preload controls>";
                        echo "<source src='". $dbvidpath . "' type='video/mp4'>";
                        echo "</video>";
                    } else {
                        echo '<script language="javascript">';
                        echo 'alert("You have exceeded the number of movies!")';
                        echo '</script>';
                    }
                } else {
                    if($dbmovie==0){
                        $db_user = mysqli_select_db(getConn(), 'login') or die("Dead User");
                        $queryuser = "UPDATE users SET movie='1', date_start = NOW(), date_end = DATE_ADD(NOW(), INTERVAL 1 MONTH) WHERE username = '$usermovie'";
                        //$queryuser = "UPDATE users SET movie='1' WHERE id = '$userid'";

                        //$dbid = $_POST['id'];
                        @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");
                        @$query = mysqli_query(getConn(), "SELECT * FROM movie where id = $dbid");
                        @$numrows = mysqli_num_rows($query);
                        while ($row = mysqli_fetch_assoc($query)) {
                            $dbvidpath = $row['videopath'];
                        }
                        echo "<video  style= 'width:853px; height:480px;' preload controls>";
                        echo "<source src='". $dbvidpath . "' type='video/mp4'>";
                        echo "</video>";
                    } else {
                        echo '<script language="javascript">';
                        echo 'alert("You have exceeded the number of movies!")';
                        echo '</script>';
                    }
                }
            }
          }
          ?>
      </div>
</div>
<div class="wrapper col7">
  <div id="copyright">

  </div>
</div>
</body>
</html>