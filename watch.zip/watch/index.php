<?php
session_start();
if($_SESSION['is_valid']==false){
    header("Location:../index.php");
    exit;
}
$user = $_SESSION['username'];
//include 'dbconfig.php';

    function getConn()
    {
      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "dirkrhys15";
      $dbname = "movie";
      $conn =  mysqli_connect($dbhost, $dbuser, $dbpass) or die('cannot connect to the server');
      mysqli_select_db($conn, $dbname) or die('database selection problem');
      return $conn;
    }


    function getImageSlider()
    {
    $str = "";
    @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");

    @$query = mysqli_query(getConn(), "SELECT * FROM movie");
    @$numrows = mysqli_num_rows($query);

    if ($numrows !== 0) {

      while ($row = mysqli_fetch_assoc($query))
      {
        $str .= "<li><a href='#".$row['id']."'>";
        $str .=   "<img src=" . $row['picturepath'] . " alt=".$row['title'].">";
        $str .= "</a></li>";
      }
    }
    @mysqli_close(getConn());
    return $str;
    }
    function getImage()
    {
    $num = $_COOKIE["test"];
    $str1 = "";
    @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");

    @$query = mysqli_query(getConn(), "SELECT * FROM movie WHERE id = $num");
    @$numrows = mysqli_num_rows($query);
    while ($row = mysqli_fetch_assoc($query))
    {
        $str1 .= "<img class='imgl' src=" . $row['picturepath'] . " alt=".$row['title']." width='150' height='200' >";
        $str1 .= "<p><strong>".$row['title']."</strong></p>";
        $str1 .= "<p>".$row['genre']."</p>";
        $str1 .= "<p>".$row['description']."</p>";
    }
        @mysqli_close(getConn());
        return $str1;
    }

function getImageFirst()
    {
    $num = $_COOKIE["test"];
    $num2 = ($num-1);
    $str1 = "";
    @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");
    @$query = mysqli_query(getConn(), "SELECT * FROM movie WHERE id = $num2");
    @$numrows = mysqli_num_rows($query);
    while ($row = mysqli_fetch_assoc($query))
    {
        $str1 .= "<li><img class='imgl' src=" . $row['picturepath'] . " alt=".$row['title']." width='60' height='80' >";
        $str1 .= "<p><strong>".$row['title']."</strong></p>";
        $str1 .= "<p>".$row['description']."</p>";
        $str1 .= "<form method='post' action='video.php'>";
        $str1 .= "<input type='hidden' value='$num2' name='store1'>"; 
        $str1 .= "<button type='submit' name='new1'><p class='readmore'>Continue Reading &raquo;</p></button>";
        $str1 .= "</form>";
    }
        @mysqli_close(getConn());
        return $str1;
    }

function getImageSecond()
    {
    $num = $_COOKIE["test"];
    $num2 = ($num-2);
    $str1 = "";
    @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");

    @$query = mysqli_query(getConn(), "SELECT * FROM movie WHERE id = $num2");
    @$numrows = mysqli_num_rows($query);
    while ($row = mysqli_fetch_assoc($query))
    {
        $str1 .= "<li><img class='imgl' src=" . $row['picturepath'] . " alt=".$row['title']." width='60' height='80' >";
        $str1 .= "<p><strong>".$row['title']."</strong></p>";
        $str1 .= "<p>".$row['description']."</p>";
        $str1 .= "<form method='post' action='video.php'>";
        $str1 .= "<input type='hidden' value='$num2' name='store2'>"; 
        $str1 .= "<button type='submit' name='new2'><p class='readmore'>Continue Reading &raquo;</p></button>";
        $str1 .= "</form>";
    }
        @mysqli_close(getConn());
        return $str1;
    }

    function clearSubmit()
    {
        if(isset($_POST['submit'])){
        unset($_POST['submit']);
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
<title>Watch Me</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<script type="text/javascript" src="layout/scripts/jquery.min.js"></script>
<script type="text/javascript" src="layout/scripts/jquery.jcarousel.pack.js"></script>
<script type="text/javascript" src="layout/scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="layout/scripts/jquery.jcarousel.setup.js"></script>
    
</head>
<body id="top">
<div class="wrapper col1">
  <div id="topbar">
    
    <ul>
        <li><?php echo $user; ?></li>
        <li class="last"><a href="../index.php" >Logout</a></li>
    </ul>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="header">
    <div class="fl_left">
      <h1>Watch Me Inc.</h1>
      <p></p>
    </div>
    
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col3">
  <div id="topnav">
    <ul>
      <li class="active"><a href="index.php">Homepage</a></li>

    </ul>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col4">
  <div id="featured_slide">
    <div id="featured_content">
      <ul>
        <?php echo getImageSlider(); ?>
        <!--- <li><a href="#"><img src="images/demo/Mockingjay_part_1_poster_2.jpg" alt="" /></a></li> --->

      </ul>
    </div>
    <a href="javascript:void(0);" id="featured-item-prev"><img src="layout/images/prev.png" alt="" /></a> <a href="javascript:void(0);" id="featured-item-next"><img src="layout/images/next.png" alt="" /></a> </div>
</div>
<div id="search">
    <br>
    <form action="" method="post">
        <strong>Search Using</strong><br><br>
        Movie Title:   <input type="text" placeholder="Movie Title" name="title" />
        <button class="btn" type="submit" name="submit">Search</button>
        <button class="btn" type="submit" name="clear" onclick="">Clear</button>
    </form>
</div>
<br><br>


<div class="movies">
    <?php
    if(isset($_POST['submit'])) {

        $dbtitle = $_POST['title'];
        $str1 = "";
        @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");
        @$query = mysqli_query(getConn(), "SELECT * FROM movie WHERE title LIKE '%{$dbtitle}%'");
        @$numrows = mysqli_num_rows($query);
        while ($row = mysqli_fetch_assoc($query)) {
            $str1 .= "<div class='wrapperinfo' id='" . $row['id'] . "'>";
            $str1 .= "<div class='wrapperimgl'>";
            $str1 .= "<img src=" . $row['picturepath'] . " alt=" . $row['title'] . " width='150' height='200' >";
            $str1 .= "</div>";
            $str1 .= "<span><strong>" . $row['title'] . "</strong></span>";
            $str1 .= "<form method='post' action='video.php'>";
            $str1 .= "<input type='hidden' value='" . $row['id'] . "' name='id'>";
            $str1 .= "<button class='wrapperbutton' type='submit' name='rent'>Rent</button>";
            $str1 .= "</form>";
            $str1 .= "</div>";
            setcookie('test',$row['id'],time()+3600);
        }

        @mysqli_close(getConn());
        echo $str1;
    } else {
        $str1 = "";
        @$select_db = mysqli_select_db(getConn(), 'movie') or die("False");

        @$query = mysqli_query(getConn(), "SELECT * FROM movie");
        @$numrows = mysqli_num_rows($query);
        while ($row = mysqli_fetch_assoc($query)) {
            $str1 .= "<div class='wrapperinfo' id='" . $row['id'] . "'>";
            $str1 .= "<div class='wrapperimgl'>";
            $str1 .= "<img src=" . $row['picturepath'] . " alt=" . $row['title'] . " width='150' height='200' >";
            $str1 .= "</div>";
            $str1 .= "<span><strong>" . $row['title'] . "</strong></span>";
            $str1 .= "<form method='post' action='video.php'>";
            $str1 .= "<input type='hidden' value='" . $row['id'] . "' name='id'>";
            $str1 .= "<button class='wrapperbutton' type='submit' name='rent'>Rent</button>";
            $str1 .= "</form>";
            $str1 .= "</div>";
            setcookie('test',$row['id'],time()+3600);
        }

        echo $str1;
    }

    ?>
</div>
        


<div class="wrapper col5">
  <div id="container">
    <div id="content">
        
      <h2>Featured Movie of the Week
        </h2>
      <?php echo getImage();?>
    </div>
    <div id="column">
      <div class="holder">
        <h2>New In Store</h2>
        <ul id="latestnews">
          <?php echo getImageFirst();?>
          <?php echo getImageSecond();?>
        </ul>
      </div>
    </div>
    <br class="clear" />
  </div>
</div>

<div class="wrapper col7">
  <div id="copyright">
    <p class="fl_left">Copyright &copy; 2014 - All Rights Reserved - <a href="#">Watch Me Inc.</a></p>
    <br class="clear" />
  </div>
</div>
</body>
</html>